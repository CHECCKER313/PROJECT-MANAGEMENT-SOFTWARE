/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Loginpage.java
 *
 * Created on Jan 1, 2015, 9:52:00 AM
 */
package billingprojectmyself;

/**
 *
 * @author God
 */

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Loginpage extends JFrame {

    public Loginpage(){
        initComponents();
          init();
    }

    private void init() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setSize(1050, 700);
        setResizable(false);
        setLocationRelativeTo(null);
        setTitle("VST BILLING");
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("logo.png")));
        setResizable(false);
         addWindowListener(new WindowAdapter() {

  @Override
  public void windowClosing(WindowEvent we)
  {
    String ObjButtons[] = {"Yes","No"};
    int PromptResult = JOptionPane.showOptionDialog(null,
        "ARE YOU SURE YOU WANT TO EXIT?", "VST BILLING",
        JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null,
        ObjButtons,ObjButtons[1]);
    if(PromptResult==0)
    {
      System.exit(0);
    }
  }
});
setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jInternalFrame1 = new javax.swing.JInternalFrame();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        loginb = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jLabel11 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jPasswordField2 = new javax.swing.JPasswordField();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("LOGIN FORM");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(370, 110, 280, 42);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 102));
        jLabel5.setText("Powered By");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(600, 590, 160, 30);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 204));
        jLabel6.setText("Nyeste Venture Technologies Pvt Ltd");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(660, 630, 390, 28);

        jInternalFrame1.setVisible(true);
        jInternalFrame1.getContentPane().setLayout(null);

        jPanel1.setLayout(null);

        loginb.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        loginb.setText("LOGIN");
        loginb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginbActionPerformed(evt);
            }
        });
        jPanel1.add(loginb);
        loginb.setBounds(300, 170, 80, 25);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("USER NAME");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(70, 70, 130, 17);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("PASSWORD");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(70, 120, 120, 17);
        jPanel1.add(jTextField1);
        jTextField1.setBounds(220, 60, 160, 30);

        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });
        jPanel1.add(jPasswordField1);
        jPasswordField1.setBounds(220, 110, 160, 30);

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel11.setText("ADMIN LOGIN");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(140, 10, 170, 22);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/loginpink.jpg"))); // NOI18N
        jPanel1.add(jLabel7);
        jLabel7.setBounds(0, 0, 410, 220);

        jTabbedPane1.addTab("   ADMIN  ", jPanel1);

        jPanel2.setLayout(null);

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel9.setText("USERNAME");
        jPanel2.add(jLabel9);
        jLabel9.setBounds(90, 70, 110, 20);

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel10.setText("PASSWORD");
        jPanel2.add(jLabel10);
        jLabel10.setBounds(90, 120, 90, 17);
        jPanel2.add(jTextField2);
        jTextField2.setBounds(240, 60, 140, 30);

        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton2.setText("LOGIN");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2);
        jButton2.setBounds(290, 160, 90, 25);

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel12.setText("USER LOGIN");
        jPanel2.add(jLabel12);
        jLabel12.setBounds(150, 20, 130, 22);

        jPasswordField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField2ActionPerformed(evt);
            }
        });
        jPanel2.add(jPasswordField2);
        jPasswordField2.setBounds(240, 110, 140, 30);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/loginpink.jpg"))); // NOI18N
        jPanel2.add(jLabel8);
        jLabel8.setBounds(0, 0, 410, 230);

        jTabbedPane1.addTab("   USER   ", jPanel2);

        jInternalFrame1.getContentPane().add(jTabbedPane1);
        jTabbedPane1.setBounds(0, 0, 420, 250);

        getContentPane().add(jInternalFrame1);
        jInternalFrame1.setBounds(310, 220, 430, 280);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Pink-Virtual-Stairs-PPT-Backgrounds - Copy.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 1070, 670);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loginbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginbActionPerformed
       adminlogin();
    }//GEN-LAST:event_loginbActionPerformed

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed
       adminlogin();
    }//GEN-LAST:event_jPasswordField1ActionPerformed
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      userlogin();
    }//GEN-LAST:event_jButton2ActionPerformed
  public void userlogin(){
      Database d = new Database();
      System.out.println("1");
      String useruser = jTextField2.getText();
      System.out.println("2");
      String pass=new String(jPasswordField2.getPassword());
      if (useruser.equals("")||pass.equals("")) {
          JOptionPane.showMessageDialog(null, "Fill All The Fields");
          System.out.println("3");
      } else {
          if (d.methodUserlogin(useruser, pass)){
              Userhome page2 = new Userhome();
              System.out.println("4");
              page2.setVisible(true);
              this.dispose();
          } else {
              JOptionPane.showMessageDialog(null, "Incorrect Username or Password");
              jTextField2.setText("");
              jPasswordField2.setText("");
          }
      }
  }
    private void jPasswordField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField2ActionPerformed
       userlogin();
    }//GEN-LAST:event_jPasswordField2ActionPerformed
    public void adminlogin(){
        Database d = new Database();
        System.out.println("1");
        String useradmin=jTextField1.getText();
        System.out.println("2");
        String passw=new String(jPasswordField1.getPassword());
        System.out.println("3");
       if(useradmin.equals("")||passw.equals("")){
           System.out.println("4");
            JOptionPane.showMessageDialog(null,"Fill All The Fields");
        }else{
           if(d.methodlogin(useradmin, passw)){
               System.out.println("5");
            Adminpage page=new Adminpage();
            System.out.println("6");
            page.setVisible(true);
            this.dispose();
        }else{
               JOptionPane.showMessageDialog(null,"Incorrect Username or Password");
               jTextField1.setText("");
               jPasswordField1.setText("");
        }
        }


    }
    public static void main(String args[]) {
         java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Loginpage().setVisible(true);
            }
        });

    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JButton loginb;
    // End of variables declaration//GEN-END:variables
}
