package billingprojectmyself;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
public class ReportAdmin1 extends javax.swing.JFrame {
DefaultTableModel dt;

     public ReportAdmin1() {
            initComponents();
            init();
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(JLabel.CENTER);
            jTable1.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
            jTable1.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);//table cell center allocation
            jTable1.getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
            jTable1.getColumnModel().getColumn(6).setCellRenderer(centerRenderer);
            int[] columnsWidth = { 60,150,150,150,100,100,150};
             int i = 0;
            for (int width : columnsWidth) {
            TableColumn column =this.jTable1.getColumnModel().getColumn(i++);
            column.setMinWidth(width);
            column.setMaxWidth(width);
            column.setPreferredWidth(width);
            }
      }
    private void init() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setSize(900, 490);
        setResizable(false);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        //setLocationRelativeTo(null);
        this.setLocation(220, 210);
        setTitle("VST BILLING");
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("logo.png")));
        setResizable(false);
    }
   @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jTable1.setBackground(new java.awt.Color(204, 255, 153));
        jTable1.setFont(new java.awt.Font("Times New Roman", 0, 14));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "BillNo", "CustomerName", "Manufacturer", "StockName", "Quantity", "Price", "Total Including Tax"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setFillsViewportHeight(true);
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(20, 80, 860, 370);

        jDateChooser1.setBackground(new java.awt.Color(204, 255, 204));
        jDateChooser1.setDateFormatString("yyyy/M/d");
        jDateChooser1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jDateChooser1FocusLost(evt);
            }
        });
        jDateChooser1.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jDateChooser1AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
                jDateChooser1AncestorRemoved(evt);
            }
        });
        jDateChooser1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jDateChooser1KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jDateChooser1KeyReleased(evt);
            }
        });
        getContentPane().add(jDateChooser1);
        jDateChooser1.setBounds(20, 40, 130, 30);

        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jButton1.setForeground(new java.awt.Color(0, 153, 51));
        jButton1.setText("VIEW");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(160, 40, 80, 23);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24));
        jLabel2.setForeground(new java.awt.Color(0, 153, 51));
        jLabel2.setText("REPORT");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(400, 20, 120, 40);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/pdf.jpg"))); // NOI18N
        jButton2.setBorder(null);
        jButton2.setContentAreaFilled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(830, 20, 50, 50);

        jLabel1.setForeground(new java.awt.Color(0, 153, 51));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Internet-Business-viewcategory.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 900, 470);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jDateChooser1AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jDateChooser1AncestorAdded
    }//GEN-LAST:event_jDateChooser1AncestorAdded

    private void jDateChooser1AncestorRemoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jDateChooser1AncestorRemoved
    }//GEN-LAST:event_jDateChooser1AncestorRemoved

    private void jDateChooser1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jDateChooser1FocusLost
    }//GEN-LAST:event_jDateChooser1FocusLost

    private void jDateChooser1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jDateChooser1KeyReleased
        
    }//GEN-LAST:event_jDateChooser1KeyReleased

    private void jDateChooser1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jDateChooser1KeyPressed
        
    }//GEN-LAST:event_jDateChooser1KeyPressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      try{
        dt = (DefaultTableModel) jTable1.getModel();
        dt.setNumRows(0);
        jDateChooser1.getDate();
        System.out.println(jDateChooser1.getDate());
        String dateString = String.format("%1$20ty/%1$tm/%1$td", jDateChooser1.getDate());
        System.out.println(dateString);
        Database d=new Database();
        d.ps=d.con.prepareStatement("select bill,manufacturer,stockname,quantity,price,total,customername from bill where date=?");
        d.ps.setString(1, dateString);
        System.out.println("1");
        d.rs=d.ps.executeQuery();
       System.out.println("2");
       while(d.rs.next()) {
            System.out.println("3");
            System.out.println(d.rs.getInt(1));
                            System.out.println("3");
                            dt.addRow(new Object[]{d.rs.getInt(1),d.rs.getString(7), d.rs.getString(2),d.rs.getString(3), d.rs.getDouble(4), d.rs.getDouble(5), d.rs.getDouble(6)});
                            System.out.println("4");
                           }
        }catch(Exception e){
        System.out.println("error"+e);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
             Document document=new Document();

            try {
               // PdfWriter.getInstance(document, new FileOutputStream("Report.pdf"));
                PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("D:/Report.pdf"));
                document.open();
                PdfPTable pdfTable = new PdfPTable(jTable1.getColumnCount());
                for (int i = 0; i <jTable1.getColumnCount(); i++) {
                pdfTable.addCell(jTable1.getColumnName(i));
            }
            //extracting data from the JTable and inserting it to PdfPTable
            for (int rows = 0; rows < jTable1.getRowCount() ; rows++) {
                for (int cols = 0; cols < jTable1.getColumnCount(); cols++) {
                    pdfTable.addCell(jTable1.getModel().getValueAt(rows, cols).toString());
                }
            }
                 String dateString = String.format("%1$20ty/%1$tm/%1$td", jDateChooser1.getDate());
                 PdfDate date=new PdfDate();
                
                document.add(pdfTable);
                document.close();
                System.out.println("pdf executed");
                JOptionPane.showMessageDialog(null,"PDF FILE IS CREATED");
                 try {
               //here writing the code to display the pdf
		File pdfFile = new File("D:\\Report.pdf");
		if (pdfFile.exists()) {

			if (Desktop.isDesktopSupported()) {
				Desktop.getDesktop().open(pdfFile);
			} else {
				System.out.println("Awt Desktop is not supported!");
			}

		} else {
			System.out.println("File is not exists!");
		}

		System.out.println("Done");

	  } catch (Exception ex) {
		ex.printStackTrace();
	  }


            } catch (DocumentException ex) {
                Logger.getLogger(ReportUser.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ReportUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
