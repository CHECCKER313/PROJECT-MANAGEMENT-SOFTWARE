/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package billingprojectmyself;

/**
 *
 * @author God
 */
public class HelloThreadrunn implements Runnable{

    public void run() {
         for(int i=0;i<5;i++){
    System.out.println("Hello from a thread");
    }
    }
    public static void main(String args[]){
        for(int i=0;i<5;i++){
    System.out.println("hai");
}
        HelloThread t=new HelloThread();
        Thread g=new Thread(t);
        g.start();
        
    }

}
