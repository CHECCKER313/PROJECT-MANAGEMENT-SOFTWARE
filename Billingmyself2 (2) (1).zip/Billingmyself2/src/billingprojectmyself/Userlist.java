/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Userlist.java
 *
 * Created on Jan 26, 2015, 8:17:22 PM
 */

package billingprojectmyself;

import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author God
 */
public class Userlist extends javax.swing.JFrame {
DefaultTableModel dt;
int count = 0;
Database d=new Database();
    /** Creates new form Userlist */
    public Userlist() {
        initComponents();
        init();
        Database d=new Database();
        System.out.println("Connected");
        try{

            dt=(DefaultTableModel)jTable1.getModel();
            dt.setNumRows(0);
            d.ps=d.con.prepareStatement("select newusername,password from user");
            d.rs=d.ps.executeQuery();
            System.out.println("Query executed");
            while(d.rs.next()){
              dt.addRow(new Object[]{d.rs.getString(1),d.rs.getString(2)});
            }System.out.println("connect row");
            // refreshupdate();
            }catch(Exception e){
            System.out.println("Error when row insertion");
           }
    }
    private void init(){
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      setExtendedState(JFrame.MAXIMIZED_BOTH);
      setSize(600,490);
      setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
      //setLocationRelativeTo(null);
      this.setLocation(370,210);
      setTitle("VST BILLING");
      setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("logo.png")));
      setResizable(false);
      setResizable(false);
    }
      @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        userid1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jTable1.setBackground(new java.awt.Color(204, 255, 153));
        jTable1.setFont(new java.awt.Font("Times New Roman", 0, 14));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "USERNAME", "PASSWORD"
            }
        ));
        jTable1.setFillsViewportHeight(true);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);
        jTable1.getColumnModel().getColumn(0).setResizable(false);
        jTable1.getColumnModel().getColumn(1).setResizable(false);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(90, 60, 380, 380);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24));
        jLabel2.setForeground(new java.awt.Color(0, 153, 51));
        jLabel2.setText("USERS");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(270, 20, 100, 20);

        jButton1.setBackground(new java.awt.Color(204, 255, 153));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14));
        jButton1.setForeground(new java.awt.Color(0, 153, 51));
        jButton1.setText("OK");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(490, 410, 90, 40);

        jButton2.setBackground(new java.awt.Color(204, 255, 153));
        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jButton2.setForeground(new java.awt.Color(0, 153, 51));
        jButton2.setText("NEW USER");
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(490, 240, 90, 40);

        jButton3.setBackground(new java.awt.Color(204, 255, 153));
        jButton3.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jButton3.setForeground(new java.awt.Color(0, 153, 51));
        jButton3.setText("UPDATE");
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(490, 300, 90, 40);

        jButton4.setBackground(new java.awt.Color(204, 255, 153));
        jButton4.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jButton4.setForeground(new java.awt.Color(0, 153, 51));
        jButton4.setText("DELETE");
        jButton4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(490, 357, 90, 40);
        getContentPane().add(userid1);
        userid1.setBounds(640, 40, 59, 20);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Internet-Business-Slides.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 620, 470);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       Newuser page=new Newuser();
       page.setVisible(true);
       this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       try {
        int row =jTable1.getSelectedRow();
        System.out.println("1");
        DefaultTableModel model= (DefaultTableModel)jTable1.getModel();
        String value=model.getValueAt(row,0).toString();
        System.out.println("2");
        jTable1.editCellAt(row, count);
        System.out.println("3");
        int id=Integer.parseInt(userid1.getText());
        if(row >= 0){
                    String username=(String) model.getValueAt(row,0);
                    System.out.println("Username is:"+username);
                    String password= (String) model.getValueAt(row,1);
                    System.out.println("password is:"+password);
                    d.methodupdateuserlist(id,username,password);
                  }
                }catch(ArrayIndexOutOfBoundsException e){
                    System.out.println("out of bound");
                    JOptionPane.showMessageDialog(null, "You Must Select The Row From The Table And Edit Within The Cell");
                }catch (Exception w) {
                   System.out.println("update stock error" +w);
                }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
    try {
        int row =jTable1.getSelectedRow();
        DefaultTableModel model= (DefaultTableModel)jTable1.getModel();
        String username= (String) model.getValueAt(row,0);
        String pass=(String)model.getValueAt(row,1);
           if (row >= 0) {

                    d.ps=d.con.prepareStatement("select userid from user where newusername=? and password=?");
                    d.ps.setString(1, username);
                    d.ps.setString(2, pass);//select stockid of the selected row rom the jtable and store it into another textfield.
                    d.rs=d.ps.executeQuery();
                    while(d.rs.next()){
                        d.rs.getInt(1);
                        userid1.setText(Integer.toString(d.rs.getInt(1)));//set selected item id to the textfield
                    }
              }
        }catch(Exception e){
            System.out.println("mouse click error"+e);
        }// TODO add y
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
        int row =jTable1.getSelectedRow();
        DefaultTableModel model= (DefaultTableModel)jTable1.getModel();
        String selected = model.getValueAt(row, 0).toString();
        int id=Integer.parseInt(userid1.getText());
           if (row >= 0) {
                    model.removeRow(row);
                    d.ps = d.con.prepareStatement("delete from user where userid='"+id+"' ");
                    d.ps.executeUpdate();
                }
                }catch(ArrayIndexOutOfBoundsException e){
                    System.out.println("out of bound");
                    JOptionPane.showMessageDialog(null, "You must select the Row from the Table");
        } catch (Exception w) {
                    JOptionPane.showMessageDialog(this, "Connection Error!");
                }
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
    * @param args the command line arguments
    */
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField userid1;
    // End of variables declaration//GEN-END:variables

}
