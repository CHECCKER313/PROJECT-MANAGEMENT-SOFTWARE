/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Billing.java
 *
 * Created on Jan 24, 2015, 12:46:48 PM
 */
package billingprojectmyself;

import java.awt.*;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.text.*;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.*;
import java.awt.print.*;
import java.util.Date;
import javax.swing.table.*;

/**
 *
 * @author God
 */
public class Billing extends javax.swing.JFrame {
    Database t=new Database();
    Database d = new Database();
    DefaultTableModel dt;
    int count = 1;
    public DateFormat d1;
    public String s = "";
    int flag = 0, fl = 0;
    String[] col = {"Col", "Col"};

    /** Creates new form Billing */
    public Billing() {
       
        initComponents();
        init();
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(JLabel.CENTER);
            jTable1.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
            jTable1.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);//table cell center allocation and set coloumn size
            jTable1.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
            jTable1.getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
            int[] columnsWidth = { 60,200,200,100,100,150};
             int i = 0;
        for (int width : columnsWidth) {
        TableColumn column =this.jTable1.getColumnModel().getColumn(i++);
        column.setMinWidth(width);
        column.setMaxWidth(width);
        column.setPreferredWidth(width);
          }
        combo1();
        trunktemp();
         int flag=0,fl=0;
    //    trunktemp();
        jTextField2.setEditable(false);
        Calendar c = Calendar.getInstance();
        d1 = new SimpleDateFormat("yyyy/MM/dd");
        s = d1.format(c.getTime());
        jTextField8.setText(s);
        try {
            Database d=new Database();
                d.ps = d.con.prepareStatement("select max(bill) from bill");
            System.out.println("1");
            d.rs = d.ps.executeQuery();
             System.out.println("2");
            while (d.rs.next()) {
                System.out.println("3");
                flag = d.rs.getInt(1);
            }
            if (flag == 0) {
                fl = 100;
            } else {
                fl = flag + 1;
            }
        } catch (Exception e) {
            System.out.println("bill id error"+e);
        }
        jTextField4.setText(Integer.toString(fl));

    }

    private void init() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setSize(1050, 700);
        setResizable(false);
        setTitle("VST BILLING");
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("logo.png")));
      setResizable(false);
         addWindowListener(new WindowAdapter() {

  @Override
  public void windowClosing(WindowEvent we)
  {
    String ObjButtons[] = {"Yes","No"};
    int PromptResult = JOptionPane.showOptionDialog(null,
        "ARE YOU SURE YOU WANT TO EXIT?", "VST BILLING",
        JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null,
        ObjButtons,ObjButtons[1]);
    if(PromptResult==0)
    {
      System.exit(0);
    }
  }
});
setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public void combo1() {
        try {

            String sql = "select * from manufacturer";
            d.ps = d.con.prepareStatement(sql);
            d.rs = d.ps.executeQuery();
            while (d.rs.next()) {
                String name = d.rs.getString("manname");
                jComboBox1.addItem(name);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Select Manufacturer");
            System.out.println("Error in combobox" + e);
        }
    }

    private void combobox2() {
        //
        jComboBox2.removeAllItems();
        System.out.println("combo1");
        String i = (String) jComboBox1.getSelectedItem();
        System.out.println("combo2");
        try {
            d.ps = d.con.prepareStatement("Select manid from manufacturer where manname=?");
            System.out.println("combo3");
            d.ps.setString(1, i);
            System.out.println("combo4");
            System.out.println("man name" + i);
            d.rs = d.ps.executeQuery();
            System.out.println("execute1");
            if(d.rs.next()) {
                int id = d.rs.getInt(1);
                System.out.println(id);
                String sql1 = "select stockname from stock where manid=?";
                d.ps = d.con.prepareStatement(sql1);
                d.ps.setInt(1, id);
                System.out.println("stock name is" + d.rs.getString(1));
                d.rs = d.ps.executeQuery();
                System.out.println("sss5");
                while (d.rs.next()) {
                    String name = d.rs.getString("stockname");
                    jComboBox2.addItem(name);
                }
                System.out.println("sss3");
            } else {
            }
        } catch (Exception e) {
            System.out.println("update002 " + e);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton6 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jTextField8 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jTextField4 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jButton6.setBackground(new java.awt.Color(255, 255, 204));
        jButton6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton6.setText("NEW");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6);
        jButton6.setBounds(90, 10, 80, 30);

        jButton1.setBackground(new java.awt.Color(255, 255, 204));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton1.setText("BACK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(10, 10, 71, 30);

        jTextField8.setEditable(false);
        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField8);
        jTextField8.setBounds(130, 70, 130, 30);

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jLabel10.setText("DATE");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(10, 80, 47, 14);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jLabel6.setText("CUSTEMOR NAME");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(10, 120, 107, 14);
        getContentPane().add(jTextField3);
        jTextField3.setBounds(130, 110, 130, 30);

        jPanel3.setBackground(new java.awt.Color(255, 255, 204));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jLabel1.setText("MANUFACTURER");

        jComboBox1.setFont(new java.awt.Font("Times New Roman", 0, 14));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jLabel3.setText("STOCK NAME");

        jComboBox2.setFont(new java.awt.Font("Times New Roman", 0, 14));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select" }));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jLabel4.setText("QUANTITY");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Times New Roman", 0, 11)); // NOI18N
        jButton3.setText("ADD");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Times New Roman", 0, 11));
        jButton4.setText("DELETE");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jComboBox1, 0, 152, Short.MAX_VALUE))
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addGap(20, 20, 20))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton3)
                        .addComponent(jButton4)))
                .addGap(39, 39, 39))
        );

        getContentPane().add(jPanel3);
        jPanel3.setBounds(300, 90, 440, 140);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12));
        jLabel5.setText("Billid");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(880, 30, 40, 15);

        jButton5.setFont(new java.awt.Font("Times New Roman", 0, 11));
        jButton5.setText("TOTAL");
        getContentPane().add(jButton5);
        jButton5.setBounds(740, 620, 80, 21);

        jTextField4.setEditable(false);
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField4);
        jTextField4.setBounds(930, 30, 70, 25);
        getContentPane().add(jTextField2);
        jTextField2.setBounds(830, 620, 97, 28);

        jButton7.setBackground(new java.awt.Color(255, 255, 204));
        jButton7.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton7.setText("PREVIEW");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7);
        jButton7.setBounds(929, 640, 110, 29);

        jLabel2.setBackground(new java.awt.Color(153, 255, 255));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24));
        jLabel2.setText("STOCK BILLING");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(420, 20, 210, 28);

        jTable1.setFont(new java.awt.Font("Times New Roman", 0, 14));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "SlNo", "Manufacturer", "StockName", "Quantity", "Price", "Total(Including Tax=5.5)"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true, false, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setFillsViewportHeight(true);
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(120, 240, 810, 380);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/userbackground.jpg"))); // NOI18N
        getContentPane().add(jLabel7);
        jLabel7.setBounds(0, 0, 1060, 690);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
        Database dt = new Database();
        int n = Integer.parseInt(jTextField8.getText());
        
}//GEN-LAST:event_jTextField8ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
}//GEN-LAST:event_jTextField4ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        combobox2();
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      try {
        String custname=jTextField3.getText();
        if(custname.equals("")){
            JOptionPane.showMessageDialog(null,"FILL CUSTOMER NAME FIELD");
        }else{
        String i = (String) jComboBox2.getSelectedItem();
       
            Double text = Double.parseDouble(jTextField1.getText());
            d.ps = d.con.prepareStatement("Select stockid from stock where stockname=?");
            d.ps.setString(1, i);
            System.out.println("stockname is " + i);
            d.rs = d.ps.executeQuery();
            System.out.println("execute1");
            //query to connect two table's id
            while (d.rs.next()) {
                int id = d.rs.getInt(1);
                System.out.println(id);
                dt = (DefaultTableModel) jTable1.getModel();
                dt.setNumRows(0);
                d.ps = d.con.prepareStatement("select price,noofstocks from stock where stockid=?");
                d.ps.setInt(1, id);
                d.rs = d.ps.executeQuery();
                System.out.println("Query executed");
                while (d.rs.next()) {
                    double h = d.rs.getDouble(1);
                    double noofstocks=d.rs.getDouble(2);
                    if(Double.parseDouble(jTextField1.getText())<=noofstocks){
                       //check the noofstocks is gratter than the biller typed quantity.

                    //get quantity
                    double quantity = Double.parseDouble(jTextField1.getText());
                    double price = d.rs.getDouble(1);
                    double quantity1 = Double.parseDouble(jTextField1.getText());
                    System.out.println("Quantity=" + quantity1);
                    System.out.println("price=" + price);
                    double total1 = quantity1 * price;
                    System.out.println("total=" + total1);
                    
                    System.out.println("Price is " + h);
                    String cobo1 = (String) jComboBox1.getSelectedItem();
                    String combo2 = (String) jComboBox2.getSelectedItem();
                    System.out.println("0");


//
                    String startDateString = jTextField8.getText();
                    DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
                    Date startDate;
                    startDate = df.parse(startDateString);
                    String newDateString = df.format(startDate);
                    System.out.println("new date string" + newDateString);
                    d.ps=d.con.prepareStatement("select * from tax");
                    d.rs=d.ps.executeQuery();
                    while(d.rs.next()){
                    double tax=d.rs.getDouble(2);
                    System.out.println("Tax in tax table is:"+tax);
                    double taxpercentage=tax/100;//get tax from Tax table and calculate the price with tax
                    System.out.println("Tax percentage of tax is:"+taxpercentage);
                    double taxprice=price+(price*taxpercentage);
                    double total = quantity * taxprice;//calculate tax (5.5%tax)
                    d.temp1(Integer.parseInt(jTextField4.getText()), newDateString, cobo1, combo2, quantity, taxprice, total, id, jTextField3.getText());
                    System.out.println("1");


                    
                    try {
                        Database s = new Database();
                        s.ps = s.con.prepareStatement("select slno,manufacturer,stockname,quantity,price,total from temp" );
                        s.rs = s.ps.executeQuery();
                        System.out.println("2");
                        while (s.rs.next()) {
                            dt.addRow(new Object[]{s.rs.getInt(1),s.rs.getString(2), s.rs.getString(3), s.rs.getDouble(4), s.rs.getDouble(5), s.rs.getDouble(6)});
                            System.out.println("3");
                        }
                        } catch (Exception e) {
                        System.out.println("error1");
                    }
                    Database db1 = new Database();
                    try {

                        db1.ps = db1.con.prepareStatement("select sum(total) from temp");
                        db1.rs = db1.ps.executeQuery();

                        if (db1.rs.next()) {
                            jTextField2.setText(db1.rs.getString(1));

                        }
                    } catch (Exception e) {
                        System.out.println("add10" + e);
                    }
                        }

                    //   d.con.close();
                    System.out.println("connect row");
                }else{
              JOptionPane.showMessageDialog(null, "Only "+noofstocks+" Quantities Are Available");
          }
            }
          }
          }
        } catch (SQLException ex) {
            System.out.println("not executed");
        } catch (Exception e) {
            System.out.println("Exception error");
        }
       
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       try {
            int row = jTable1.getSelectedRow();
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
           // jTable1.editCellAt(row, count);
            String selected = model.getValueAt(row, 0).toString();
            System.out.println("selected" + selected);
            if (row >= 0) {
                model.removeRow(row);
                Database d = new Database();
                d.ps = d.con.prepareStatement("delete from temp where slno='"+selected+"'");
                d.ps.executeUpdate();
                System.out.println("delete performed");
            }
            Database db1=new Database();
            db1.ps = db1.con.prepareStatement("select sum(total) from temp");
            db1.rs = db1.ps.executeQuery();

                        if (db1.rs.next()) {
                            jTextField2.setText(db1.rs.getString(1));
                        }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("out of bound");
            JOptionPane.showMessageDialog(null, "You must select the Row from the Table");
        } catch (Exception w) {
            JOptionPane.showMessageDialog(this, "Connection Error!");
        }

    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        dt = (DefaultTableModel) jTable1.getModel();
        dt.setNumRows(0);
        trunktemp();
        jTextField3.setText("");
        jTable1.setEnabled(false);
        jTextField2.setText("");
        int billid = Integer.parseInt(jTextField4.getText());
        int i = billid + 1;
        jTextField4.setText(Integer.toString(i));
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        Print page=new Print();
        page.setVisible(true);
        this.dispose();
}//GEN-LAST:event_jButton7ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Userhome page = new Userhome();
        page.setVisible(true);
        this.dispose();
}//GEN-LAST:event_jButton1ActionPerformed
public void trunktemp(){
     try {
            Database db1 = new Database();
            System.out.println("delete");
            db1.ps = db1.con.prepareStatement("truncate table temp");
            db1.ps.executeUpdate();
            System.out.println("delete");
        } catch (Exception e) {
            System.out.println("error" + e);
        }
}    /**
     * @param args the command line arguments
     */
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField8;
    // End of variables declaration//GEN-END:variables
}
