package billingprojectmyself;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class Database {
Connection con;
PreparedStatement ps;
ResultSet rs;
String query;

Database() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/billingproject", "root", "");
            System.out.println("connection established");
        } catch (Exception e) {
            System.out.println("connection failed" + e);
        }
    }
public boolean methodlogin(String username,String password) {
        try {

            ps = con.prepareStatement("select * from login where username=? and password=?");
            System.out.println("d admin 1");
        } catch (Exception e) {
            System.out.println("connection failed" + e);
        }
        try {

            ps.setString(1, username); //this replaces the 1st  "?" in the query for username
            System.out.println("d admin 2");
            ps.setString(2, password);    //this replaces the 2st  "?" in the query for password
            System.out.println("d admin 3");
            //executes the prepared statement
            rs = ps.executeQuery();
            System.out.println("d admin 4");

            if (rs.next()) {
                System.out.println("d admin 5");
                //TRUE iff the query founds any corresponding data
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            System.out.println("error while validating" + e);
            return false;

        }
    }
public boolean methodUserlogin(String username,String password) {
     try
     {

       ps=con.prepareStatement("select * from user where newusername=? and password=?");
     }catch(Exception e){
        System.out.println("connection failed"+e);
     }
     try {

            ps.setString(1, username); //this replaces the 1st  "?" in the query for username
            ps.setString(2, password); //this replaces the 2st  "?" in the query for password
            //executes the prepared statement
            rs=ps.executeQuery();

            if(rs.next())
            {
                //TRUE iff the query founds any corresponding data
                return true;
            }
            else
            {
                return false;
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            System.out.println("error while validating"+e);
            return false;
        }
}

  boolean methodAddnewuser(String username, String password, String conpassword) {
        try{
            ps=con.prepareStatement("select * from user where password=?");//check i the password already saved in the table user
            ps.setString(1,password);
            System.out.println("1");
            rs=ps.executeQuery();
            System.out.println("1");
            if(rs.absolute(1)) {
                con.close();
                System.out.println("1");
            }else{
           String insert="insert into user" +"(newusername,password, confirmpassword) values"+ "(?, ?, ?)";
           ps = con.prepareStatement(insert);
           JOptionPane.showMessageDialog(null, "You Successfully added a User.\nUSERNAME : "+username+"\nPASSWORD : "+password);
              } 
        } catch (Exception e) {
                   System.out.println("connection failed"+e);
               }
               try{
                   ps.setString(1, username);
                   ps.setString(2, password);
                   ps.setString(3, conpassword);
                   ps.executeUpdate();
                  }catch(Exception e){
                    JOptionPane.showMessageDialog(null,"The password is already exists.Please Enter Another Password");
                   System.out.println("Not inserted"+e);
                   return false;
               }
               return true;
     }
  boolean methodNewcategory(String name){
      try{
          String insert="insert into category"+"(categoryname) values"+ "(?)";
          ps=con.prepareStatement(insert);
      }catch(Exception e){
          System.out.println("newcategory connection failed" +e);
          return false;

      }
      try{
          ps.setString(1, name);
          ps.executeUpdate();
      }catch(Exception e){
          System.out.println("Not inserted new category "+e);
          return false;
      }
      return true;
  }
  
  boolean methodupdate(int id,String name){
     try{
         String update="update category set categoryname=? where categoryid=?";
         ps=con.prepareStatement(update);
          ps.setString(1, name);
         ps.setInt(2, id);
        
         ps.executeUpdate();
     }catch(Exception e){
        System.out.println("update error "+e);
     }


      return true;
  }
   boolean methodupdateman(int id,String name){
     try{
         String update="update manufacturer set manname=? where manid=?";
         ps=con.prepareStatement(update);
         ps.setString(1, name);
         ps.setInt(2, id);
         ps.executeUpdate();
         }catch(Exception e){
        System.out.println("update error "+e);
     }


      return true;

  }
   boolean methodupdateuserlist(int id,String username,String pass){
     try{
         String update="update user set newusername=?,password=? where userid=?";
         ps=con.prepareStatement(update);
          ps.setString(1, username);
          ps.setString(2, pass);
          ps.setInt(3,id );
          ps.executeUpdate();
     }catch(Exception e){
        System.out.println("update error "+e);
     }


      return true;

  }
   boolean methodaddcat(String cat){
        try {
            ps = con.prepareStatement("select * from category where categoryname=?");//check i the password already saved in the database
            ps.setString(1, cat);
            System.out.println("1");
            rs = ps.executeQuery();
            System.out.println("1");
            if (rs.absolute(1)) {
                con.close();
                System.out.println("1");
            } else {
                String insert = "insert into category" + "(categoryname) values" + "(?)";
                ps = con.prepareStatement(insert);
                JOptionPane.showMessageDialog(null, "You Successfully Added A CATEGORY");
            }
        } catch (Exception e) {
            System.out.println("Connection failed" + e);
        }
        try {
            ps.setString(1, cat);
            ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "The Category Is Already Exists.Please Enter Another Category");
            return false;
        }
        return true;

    }

 public void temp1(int billid,String date,String manuf,String stock,double quan,double price,double total,int stockid,String customername)
{
     try
    {
        System.out.println("Temp1");
        ps=con.prepareStatement("insert into temp(bill,date,manufacturer,stockname,quantity,price,total,stockid,customername) values(?,?,?,?,?,?,?,?,?)");
        // ps.setInt(1,BillId);
        ps.setInt(1,billid);
        ps.setString(2,date);
        System.out.println("Temp12");
        ps.setString(3,manuf);
        ps.setString(4,stock);
         System.out.println("Temp13");
        ps.setDouble(5,quan);
        ps.setDouble(6,price);
        ps.setDouble(7,total);
        ps.setInt(8, stockid);
        ps.setString(9,customername);
        System.out.println("Temp14");
        ps.executeUpdate();
    }
    catch(Exception e)
    {
    System.out.println("error"+e);
    }
    }


}
