/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package billingprojectmyself;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author God
 */
public class DifferentThreadTest {

    public static void main(String args[]) {
        A a = new A();
        a.setPriority(Thread.MIN_PRIORITY);
        A b = new A();
        Thread t = new Thread() {

            public void run() {

                for (int i = 0;i<20; i++) {
                    try {
                        Thread.sleep(100);
                        System.out.println(i);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(DifferentThreadTest.class.getName()).log(Level.SEVERE, null, ex);
                    }



                }
            }
        };
        t.start();
        Thread p=new Thread(){
            public void run(){
                for(int i=100;i<150;i++){
                    try {
                        Thread.sleep(20);
                        System.out.println(i);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(DifferentThreadTest.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
            }
        };
        p.start();

        b.setPriority(Thread.MAX_PRIORITY);
        A c = new A();
        c.setPriority(Thread.NORM_PRIORITY);
        a.start();
        for (int i = 0; i < 5; i++) {
            System.out.println("a min");
        }
        b.start();
        for (int i = 0; i < 5; i++) {
            System.out.println("b max");
        }
        c.start();
        for (int i = 0; i < 5; i++) {
            System.out.println("c norm");
        }
//    new C().setPriority(Thread.MAX_PRIORITY);
//    new A().setPriority(Thread.MIN_PRIORITY);
//    new B().setPriority(Thread.NORM_PRIORITY);
//    new A().start();
//    new C().start();
//    new B().start();
    }
}
