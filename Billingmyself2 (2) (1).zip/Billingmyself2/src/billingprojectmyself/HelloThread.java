/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package billingprojectmyself;

/**
 *
 * @author God
 */
public class HelloThread extends Thread{
public void run(){
    for(int i=0;i<5;i++){
    System.out.println("Hello from a thread");
    }
}
public static void main(String args[]){
    HelloThread n=new HelloThread();
    n.start();
    for(int i=0;i<5;i++){
    System.out.println("hai");
}
    }
}
