/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package billingprojectmyself;

public class SynchronizedCounter {

	private int c = 0;
	public synchronized void increment() {
		c++;
	}
	public synchronized void decrement() {
		c--;
	}
	public synchronized int value() {
 		return c;
	}
         public static void main(String args[]){
             SynchronizedCounter s=new SynchronizedCounter();
            // s.increment();
             s.decrement();
             System.out.println(s.value());
}
}

